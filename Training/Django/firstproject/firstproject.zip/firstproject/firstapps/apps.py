from django.apps import AppConfig


class FirstappsConfig(AppConfig):
    name = 'firstapps'
