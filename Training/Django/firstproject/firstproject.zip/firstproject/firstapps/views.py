from django.shortcuts import render

# Create your views here.
def index(request):
    mydct = {"insert":"sample html project"}
    return render(request,"firstapps/index.html", context=mydct)