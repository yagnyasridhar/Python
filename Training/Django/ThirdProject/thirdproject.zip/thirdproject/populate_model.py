import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "thirdproject.settings")

import django
django.setup()

import random
from model.models import AccessRecord, Topic, Webpage
from faker import Faker

fakergen = Faker()
topic = ["News", "Social"]

def add_topic():
    t = Topic.objects.get_or_create(top_name=random.choice(topic))[0]
    t.save()
    return t

def populate(n=5):
    for entry in range(n):
        top = add_topic()
        fake_url = fakergen.url
        fake_date = fakergen.date
        fake_name = fakergen.company

        web = Webpage.objects.get_or_create(topic=top, url=fake_url, name=fake_name)[0]

        acc = AccessRecord.objects.get_or_create(name=web)[0]

if(__name__ == "__main__"):
    print("started")
    populate(20)
    print("completed")