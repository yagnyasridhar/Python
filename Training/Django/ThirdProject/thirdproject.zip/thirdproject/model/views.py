from django.shortcuts import render
from model.models import AccessRecord, Webpage,Topic
# Create your views here.

def index(request):
    acclst = AccessRecord.objects.order_by("date")
    accDic = {"accessrecord":acclst}
    return render(request, "index.html", context=accDic)
