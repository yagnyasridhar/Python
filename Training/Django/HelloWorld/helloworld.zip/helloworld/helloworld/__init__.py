#django-admin startproject helloworld
#py manage.py runserver
#py manage.py startapp firstApp