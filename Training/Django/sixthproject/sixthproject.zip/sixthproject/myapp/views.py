from django.shortcuts import render
from myapp.forms import userform, UserProfileInfo
from django.template import RequestContext
import datetime

# Create your views here.
def index(request):
    return render(request, "index.html")

def register(request):
    registered = False
    if request.method == "POST":
        user_form = userform(data=request.POST)
        UserProfileInfo_form = UserProfileInfo(data=request.POST)

        if user_form.is_valid() and UserProfileInfo_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()

            request.session['email'] = user.email

            profile = UserProfileInfo_form.save(commit=False)
            profile.user = user
            if 'profile_pic' in request.FILES:
                profile.profilepic = request.FILES["profile_pic"]

            profile.save()
            registered = True
        else:
            print(user_form.errors, UserProfileInfo_form.errors)
    else:
        user_form = userform()
        UserProfileInfo_form = UserProfileInfo()

    response = render(request, 'registration.html', 
    {"registered":registered,
    "form":user_form,"profile":UserProfileInfo_form})
   
    response.set_cookie('last_connection', datetime.datetime.now())
	
    return response

