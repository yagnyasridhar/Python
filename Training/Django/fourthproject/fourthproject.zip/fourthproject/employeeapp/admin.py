from django.contrib import admin
from employeeapp.models import Employee
# Register your models here.

admin.site.register(Employee)
