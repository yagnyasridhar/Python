from django.shortcuts import render
from . import forms

# Create your views here.
def index(request):
    return render(request,"index.html")

def employee(request):      
    empform = forms.Employee()

    if(request.method == "POST"):
        empform = forms.Employee(request.POST)
        if(empform.is_valid()):
            empform.save(commit=True)
        render(request,"index.html")
    return render(request,"employee.html", {"form":empform})