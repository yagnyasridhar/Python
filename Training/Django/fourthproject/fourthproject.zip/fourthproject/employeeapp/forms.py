from django import forms
from django.core import validators
from employeeapp.models import Employee as empmodel

class Employee(forms.ModelForm):
    FirstName = forms.CharField(max_length=40)
    LastName = forms.CharField(max_length=30)
    Email = forms.EmailField(required=True, validators=[validators.EmailValidator])
    verifyEmail = forms.EmailField(label="Re-enter email")
    Comments = forms.CharField(widget=forms.Textarea)
    botcacher = forms.CharField(required=False,widget=forms.HiddenInput,
                 validators= [validators.MaxLengthValidator(0)])

    def clean(self):
        all_clean_data = super().clean()
        email = all_clean_data["Email"]
        vemail = all_clean_data["verifyEmail"]

        if(email != vemail):
            raise forms.ValidationError("Please enter appropriate email")
    class Meta():
        model = empmodel
        fields = '__all__'
