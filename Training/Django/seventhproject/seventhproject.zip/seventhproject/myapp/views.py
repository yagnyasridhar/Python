from django.shortcuts import render
from django.views.generic import View, TemplateView, ListView, DetailView
from django.http import HttpResponse
from . import models

class CBV(View):
    def get(self, request):
        return HttpResponse("CBV sample")

class StudentListview(ListView):
    models = models.School
    template_name = "list.html"
    context_object_name = "school_list"

    def get_queryset(self):
        return models.School.objects.order_by('name')


class StudentDetailview(DetailView):
    models = models.School
    template_name = "detail.html"
    context_object_name = "school_detail"

    def get_queryset(self):
        return models.School.objects.order_by('name')
    '''
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
    '''
        
def index(request):
    return render(request,"index.html")
