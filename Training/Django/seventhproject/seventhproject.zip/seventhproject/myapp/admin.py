from django.contrib import admin
from myapp.models import School,student
# Register your models here.

admin.site.register(School)
admin.site.register(student)