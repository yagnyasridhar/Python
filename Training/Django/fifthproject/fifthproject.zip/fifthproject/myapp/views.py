from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,"main.html")

def dummy(request):
    dc = {"text":"hello world"}
    return render(request,"dummy.html", context=dc)