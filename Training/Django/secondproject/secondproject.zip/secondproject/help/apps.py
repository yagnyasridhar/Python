from django.apps import AppConfig


class HelpConfig(AppConfig):
    name = 'help'
